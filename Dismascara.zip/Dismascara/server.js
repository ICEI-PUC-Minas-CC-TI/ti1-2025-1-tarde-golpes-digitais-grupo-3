const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

const COMMENTS_FILE = 'comments.json';

app.use(express.static('public'));
app.use(bodyParser.json());

// Carregar comentários
app.get('/api/comments', (req, res) => {
  fs.readFile(COMMENTS_FILE, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Erro ao ler os comentários.' });
    res.json(JSON.parse(data));
  });
});

// Adicionar novo comentário
app.post('/api/comments', (req, res) => {
  const { username, text } = req.body;
  if (!username || !text) return res.status(400).json({ error: 'Dados incompletos.' });

  const newComment = {
    username,
    text,
    timestamp: new Date().toISOString().slice(0, 16).replace('T', ' ')
  };

  fs.readFile(COMMENTS_FILE, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Erro ao ler os comentários.' });
    const comments = JSON.parse(data);
    comments.push(newComment);

    fs.writeFile(COMMENTS_FILE, JSON.stringify(comments, null, 2), err => {
      if (err) return res.status(500).json({ error: 'Erro ao salvar comentário.' });
      res.json(newComment);
    });
  });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
