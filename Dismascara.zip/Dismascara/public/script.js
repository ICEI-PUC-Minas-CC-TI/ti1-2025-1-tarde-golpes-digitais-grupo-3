async function loadComments() {
  try {
    const response = await fetch('/api/comments');
    const comments = await response.json();
    renderComments(comments);
  } catch (err) {
    console.error('Erro ao carregar comentários:', err);
  }
}

function renderComments(comments) {
  const section = document.getElementById('comments-section');
  section.innerHTML = '';
  comments.forEach(comment => {
    const div = document.createElement('div');
    div.className = 'comment';
    div.innerHTML = `
      <p class="author">${comment.username}</p>
      <p>${comment.text}</p>
      <p class="timestamp">${comment.timestamp}</p>
    `;
    section.appendChild(div);
  });
}

async function addComment() {
  const username = document.getElementById('username').value.trim();
  const text = document.getElementById('comment-text').value.trim();
  if (!username || !text) {
    alert('Preencha nome e comentário.');
    return;
  }

  const response = await fetch('/api/comments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, text })
  });

  if (response.ok) {
    document.getElementById('username').value = '';
    document.getElementById('comment-text').value = '';
    loadComments();
  } else {
    alert('Erro ao enviar comentário.');
  }
}

loadComments();
